# CloneX Infinity — Basic Android App

A native Kotlin + Jetpack Compose starter project for managing up to 10 local profile configurations.

## Implemented
- Add up to 10 profile records
- Rename and delete profile records
- Persistent local storage using Preferences DataStore
- English/Urdu UI toggle
- Dark/light theme toggle
- Dashboard counter and progress indicator

## Not implemented
This is not an app virtualization engine. It does not duplicate installed APKs, create isolated Android users, or launch independent WhatsApp/Facebook/etc. instances. Real app cloning requires supported Android/OEM profile mechanisms or a separately engineered and legally compliant virtualization solution.

## Build
Open this folder in Android Studio, allow Gradle sync, then run the `app` configuration on an Android device or emulator.
