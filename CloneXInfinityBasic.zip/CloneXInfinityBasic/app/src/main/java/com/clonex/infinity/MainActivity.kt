package com.clonex.infinity

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

private val android.content.Context.dataStore by preferencesDataStore(name = "clonex_settings")
private const val MAX_PROFILES = 10

data class CloneProfile(val id: String, val name: String, val icon: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CloneXApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CloneXApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()
    val key = remember { stringPreferencesKey("profiles_json") }
    val profiles by context.dataStore.data.map { prefs ->
        val raw = prefs[key] ?: "[]"
        runCatching {
            val arr = JSONArray(raw)
            List(arr.length()) { i ->
                val obj = arr.getJSONObject(i)
                CloneProfile(obj.getString("id"), obj.getString("name"), obj.optString("icon", "🧩"))
            }
        }.getOrDefault(emptyList())
    }.collectAsState(initial = emptyList())

    var english by remember { mutableStateOf(true) }
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<CloneProfile?>(null) }
    var nameInput by remember { mutableStateOf("") }
    var infoProfile by remember { mutableStateOf<CloneProfile?>(null) }
    var darkMode by remember { mutableStateOf(true) }

    val bg = if (darkMode) Color(0xFF0B1020) else Color(0xFFF3F5FA)
    val panel = if (darkMode) Color(0xFF171F35) else Color.White
    val fg = if (darkMode) Color(0xFFF5F7FF) else Color(0xFF12182B)
    val muted = if (darkMode) Color(0xFFADB8D0) else Color(0xFF59657A)
    val accent = Color(0xFF7C5CFC)

    fun serialize(list: List<CloneProfile>): String {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("icon", it.icon))
        }
        return arr.toString()
    }
    suspend fun save(list: List<CloneProfile>) {
        context.dataStore.edit { it[key] = serialize(list) }
    }

    MaterialTheme(colorScheme = if (darkMode) darkColorScheme(
        primary = accent, background = bg, surface = panel, onSurface = fg
    ) else lightColorScheme(primary = accent, background = bg, surface = panel, onSurface = fg)) {
        Scaffold(
            containerColor = bg,
            topBar = {
                TopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(40.dp).background(
                                    Brush.linearGradient(listOf(accent, Color(0xFF24C6DC))),
                                    RoundedCornerShape(13.dp)
                                ),
                                contentAlignment = Alignment.Center
                            ) { Icon(Icons.Default.Layers, null, tint = Color.White) }
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text("CloneX Infinity", fontWeight = FontWeight.ExtraBold, color = fg)
                                Text(if (english) "MULTI PROFILE MANAGER" else "ملٹی پروفائل مینیجر",
                                    fontSize = 10.sp, color = muted, letterSpacing = 1.2.sp)
                            }
                        }
                    },
                    actions = {
                        IconButton(onClick = { english = !english }) {
                            Icon(Icons.Default.Language, contentDescription = "Language", tint = fg)
                        }
                        IconButton(onClick = { darkMode = !darkMode }) {
                            Icon(Icons.Default.Settings, contentDescription = "Theme", tint = fg)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = bg)
                )
            },
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { nameInput = ""; showAdd = true },
                    containerColor = accent, contentColor = Color.White
                ) { Icon(Icons.Default.Add, contentDescription = "Add profile") }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 10.dp, bottom = 100.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Column(
                        Modifier.fillMaxWidth()
                            .background(Brush.linearGradient(listOf(Color(0xFF6246EA), Color(0xFF177EBD))),
                                RoundedCornerShape(24.dp))
                            .padding(20.dp)
                    ) {
                        Text(if (english) "Your space. Your profiles." else "آپ کی جگہ، آپ کے پروفائلز",
                            color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            if (english) "Organize up to 10 separate profile configurations."
                            else "10 تک الگ پروفائل کنفیگریشنز منظم کریں۔",
                            color = Color(0xFFE6E7FF), fontSize = 13.sp
                        )
                        Spacer(Modifier.height(18.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("${profiles.size} / $MAX_PROFILES", color = Color.White,
                                    fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                                Text(if (english) "Profiles created" else "بنائے گئے پروفائلز",
                                    color = Color(0xFFE6E7FF), fontSize = 12.sp)
                            }
                            Box(Modifier.size(58.dp).background(Color.White.copy(alpha = .17f), CircleShape),
                                contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Layers, null, tint = Color.White, modifier = Modifier.size(29.dp))
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        LinearProgressIndicator(
                            progress = { profiles.size / MAX_PROFILES.toFloat() },
                            modifier = Modifier.fillMaxWidth().height(6.dp),
                            color = Color.White, trackColor = Color.White.copy(alpha = .22f)
                        )
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (english) "My profiles" else "میرے پروفائلز",
                            color = fg, fontSize = 19.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f))
                        Text("${profiles.size} ${if (english) "items" else "آئٹمز"}",
                            color = muted, fontSize = 12.sp)
                    }
                }
                if (profiles.isEmpty()) {
                    item {
                        Column(
                            Modifier.fillMaxWidth().background(panel, RoundedCornerShape(20.dp)).padding(26.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("🧩", fontSize = 38.sp)
                            Spacer(Modifier.height(8.dp))
                            Text(if (english) "No profiles yet" else "ابھی کوئی پروفائل نہیں",
                                color = fg, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            Text(if (english) "Tap + to create your first profile." else "پہلا پروفائل بنانے کے لیے + دبائیں۔",
                                color = muted, fontSize = 13.sp)
                        }
                    }
                } else {
                    items(profiles, key = { it.id }) { profile ->
                        Row(
                            Modifier.fillMaxWidth().background(panel, RoundedCornerShape(18.dp)).padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(48.dp).background(accent.copy(alpha = .16f), RoundedCornerShape(14.dp)),
                                contentAlignment = Alignment.Center) { Text(profile.icon, fontSize = 24.sp) }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(profile.name, color = fg, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                                Text(if (english) "Profile configuration • ${profile.id.take(8)}"
                                    else "پروفائل سیٹنگز • ${profile.id.take(8)}", color = muted, fontSize = 11.sp)
                            }
                            IconButton(onClick = { infoProfile = profile }) {
                                Icon(Icons.Default.Layers, contentDescription = "Open profile", tint = accent)
                            }
                            IconButton(onClick = { editing = profile; nameInput = profile.name }) {
                                Icon(Icons.Default.Edit, contentDescription = "Rename", tint = muted)
                            }
                            IconButton(onClick = { scope.launch { save(profiles.filterNot { it.id == profile.id }) } }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFE66A80))
                            }
                        }
                    }
                }
                item {
                    Text(
                        if (english)
                            "Note: These are independent CloneX profile records, not isolated copies of other installed apps."
                        else
                            "نوٹ: یہ CloneX کے الگ پروفائل ریکارڈز ہیں، دوسری انسٹال شدہ ایپس کی مکمل الگ کاپیاں نہیں۔",
                        color = muted, fontSize = 12.sp, lineHeight = 18.sp,
                        modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
                    )
                }
            }
        }
    }

    if (showAdd || editing != null) {
        val isEditing = editing != null
        AlertDialog(
            onDismissRequest = { showAdd = false; editing = null },
            containerColor = panel,
            title = { Text(if (isEditing) (if (english) "Rename profile" else "پروفائل کا نام بدلیں")
                else (if (english) "Create profile" else "نیا پروفائل"), color = fg) },
            text = {
                Column {
                    OutlinedTextField(
                        value = nameInput, onValueChange = { nameInput = it.take(32) },
                        label = { Text(if (english) "Profile name" else "پروفائل کا نام") },
                        singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(if (english) "Saved only inside CloneX." else "صرف CloneX میں محفوظ ہوگا۔",
                        color = muted, fontSize = 12.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val cleaned = nameInput.trim()
                    if (cleaned.isNotEmpty()) {
                        scope.launch {
                            val updated = if (isEditing) {
                                profiles.map { if (it.id == editing!!.id) it.copy(name = cleaned) else it }
                            } else if (profiles.size < MAX_PROFILES) {
                                profiles + CloneProfile(java.util.UUID.randomUUID().toString(), cleaned,
                                    listOf("🧩", "🚀", "🌙", "🎮", "⭐", "💎", "🦊", "🌈", "⚡", "🎯")[profiles.size])
                            } else profiles
                            save(updated)
                        }
                        showAdd = false
                        editing = null
                    }
                }) { Text(if (english) "Save" else "محفوظ کریں") }
            },
            dismissButton = {
                TextButton(onClick = { showAdd = false; editing = null }) {
                    Text(if (english) "Cancel" else "منسوخ")
                }
            }
        )
    }

    infoProfile?.let { profile ->
        AlertDialog(
            onDismissRequest = { infoProfile = null },
            containerColor = panel,
            title = { Text("${profile.icon} ${profile.name}", color = fg) },
            text = {
                Text(
                    if (english)
                        "This is a saved CloneX profile. Running a separate copy of another app is not implemented in this basic version."
                    else
                        "یہ محفوظ شدہ CloneX پروفائل ہے۔ اس بنیادی ورژن میں دوسری ایپ کی الگ کاپی چلانے کی سہولت شامل نہیں۔",
                    color = muted
                )
            },
            confirmButton = {
                TextButton(onClick = { infoProfile = null }) {
                    Text(if (english) "Got it" else "ٹھیک ہے")
                }
            }
        )
    }
}
